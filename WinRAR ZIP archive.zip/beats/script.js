
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  
  if (currentScrollPos > 160) { // Проверка на 160px
    if (prevScrollpos > currentScrollPos) {
      document.getElementById("navbar").style.top = "0";
    } else {
      document.getElementById("navbar").style.top = "-80px";
    }
  } else {
    document.getElementById("navbar").style.top = "0"; 
  }
  
  prevScrollpos = currentScrollPos;
}



$(document).ready(function() {
  $('.Unit__slider').slick({
    slidesToScroll: 1,
    infinite:false,
    variableWidth: true,
    adaptiveHeight: true,
    arrows: true,
  });
})




function checkWidth() {
  if (window.innerWidth < 768) {
      
        $(document).ready(function() {
          $('.sider').slick({
            slidesToScroll: 1,
            centerMode: true,
            infinite:false,
            variableWidth: true,
            adaptiveHeight: true,
            arrows: true,
          });
        })
  }
}

// Проверка ширины при загрузке страницы
checkWidth();

// Проверка при изменении размера окна
window.addEventListener('resize', checkWidth);
